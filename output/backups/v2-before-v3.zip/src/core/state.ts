import type { Progress, Settings } from './types';
import { practices, lessons } from './academy';
import { rooms, levelInfo } from './progression';
export const SAVE_KEY = 'so-mais-um-deploy.v1';
export const SETTINGS_KEY = 'so-mais-um-deploy.settings.v1';
export const defaultSettings = (): Settings => ({ volume: 0.35, muted: false, textSpeed: 'normal', reducedMotion: false, ambience:false,ambienceVolume:0.15,highContrast:false,uiScale:'normal',moveSpeed:'normal',objectLabels:true,showControls:true,celebrations:true });
export const freshProgress = (settings = defaultSettings()): Progress => ({ version: 2, current: 0, completed: [], attempts: [0, 0, 0, 0, 0], hints: [0, 0, 0, 0, 0], settings: { ...settings },practiceCompleted:[],lessonCompleted:[],practiceAttempts:{},room:0 });
const countsValid = (a: unknown): a is number[] => Array.isArray(a) && a.length === 5 && a.every(n => Number.isSafeInteger(n) && n >= 0 && n <= 1000000);
function validSettings(s: Settings) {
  return s && Number.isFinite(s.volume) && s.volume >= 0 && s.volume <= 1 && typeof s.muted === 'boolean' && typeof s.reducedMotion === 'boolean' && ['instant', 'normal', 'slow'].includes(s.textSpeed)
    && ['ambience','highContrast','objectLabels','showControls','celebrations'].every(key => typeof s[key as keyof Settings] === 'boolean')
    && Number.isFinite(s.ambienceVolume) && s.ambienceVolume >= 0 && s.ambienceVolume <= 1 && ['compact','normal','large'].includes(s.uiScale) && ['relaxed','normal','fast'].includes(s.moveSpeed);
}
export function parseSave(raw: string | null): Progress | null {
  if (!raw) return null;
  try {
    const p = JSON.parse(raw) as Omit<Progress,'version'> & { version:number };
    if (!p || ![1,2].includes(p.version) || !Number.isInteger(p.current) || p.current < 0 || p.current > 5 || !Array.isArray(p.completed) || p.completed.length !== p.current || !p.completed.every((id, i) => id === i) || !countsValid(p.attempts) || !countsValid(p.hints)) return null;
    if (p.version === 1) {
      p.settings = { ...defaultSettings(),...p.settings };
      p.practiceCompleted=[];p.lessonCompleted=[];p.practiceAttempts={};p.room=0;p.version=2;
    }
    const s = p.settings;
    if (!validSettings(s)) return null;
    const uniqueIds = (ids: unknown, allowed: string[]) => Array.isArray(ids) && new Set(ids).size === ids.length && ids.every(id => allowed.includes(id));
    if (!uniqueIds(p.practiceCompleted,practices.map(t=>t.id)) || !uniqueIds(p.lessonCompleted,lessons.map(l=>l.id)) || !p.practiceAttempts || typeof p.practiceAttempts !== 'object' || Array.isArray(p.practiceAttempts) || !Object.entries(p.practiceAttempts).every(([id,n]) => practices.some(t=>t.id===id) && Number.isSafeInteger(n) && n>=0 && n<=1000000) || !Number.isInteger(p.room) || p.room<0 || p.room>3) return null;
    const restored = structuredClone(p) as Progress;
    if (rooms[restored.room].level > levelInfo(restored).level) restored.room=0;
    return restored;
  } catch { return null; }
}
export function completeMission(p: Progress, id: number): boolean {
  if (id !== p.current || id > 4) return false;
  p.completed.push(id); p.current++; return true;
}
export interface StorageLike { getItem(key: string): string | null; setItem(key: string, value: string): void }
export class SaveStore {
  error = '';
  constructor(private storage: StorageLike) {}
  loadSettings(): Settings | null {
    try { const data = JSON.parse(this.storage.getItem(SETTINGS_KEY) ?? 'null'); const settings = { ...defaultSettings(),...data?.settings }; return [1,2].includes(data?.version) && validSettings(settings) ? settings : null; } catch { return null; }
  }
  saveSettings(settings: Settings) {
    try { this.storage.setItem(SETTINGS_KEY, JSON.stringify({ version: 2, settings })); return true; }
    catch { this.error = 'Não foi possível salvar as configurações. Elas valem nesta sessão.'; return false; }
  }
  load() {
    try {
      const raw = this.storage.getItem(SAVE_KEY); const parsed = parseSave(raw);
      if (raw && !parsed) this.error = 'Save inválido ou de outra versão. Você pode começar uma nova campanha.';
      return parsed;
    } catch { this.error = 'Armazenamento indisponível. A campanha continua nesta sessão.'; return null; }
  }
  save(p: Progress) {
    try { this.storage.setItem(SAVE_KEY, JSON.stringify(p)); this.error = ''; return true; }
    catch { this.error = 'Não foi possível salvar. Seu progresso permanece nesta sessão.'; return false; }
  }
}
