import Phaser from 'phaser';
export type ByteMood = 'wave' | 'think' | 'success' | 'error';
// A rig made of procedural pixel parts, modeled after the supplied blue CRT.
// Limbs, screen, bezel and expression are rendered separately every frame.
export class ByteActor extends Phaser.GameObjects.Container {
  private art: Phaser.GameObjects.Graphics;
  private bubble: Phaser.GameObjects.Text;
  private mood: ByteMood | null = null;
  private until = 0;
  private direction = 'down';
  constructor(scene: Phaser.Scene, x: number, y: number) {
    super(scene,x,y); scene.add.existing(this); this.art = scene.add.graphics(); this.add(this.art);
    this.bubble = scene.add.text(0,-78,'',{fontFamily:'monospace',fontSize:'12px',color:'#182936',backgroundColor:'#f0c684',padding:{x:7,y:5}}).setOrigin(.5); this.add(this.bubble);
  }
  react(mood: ByteMood) { this.mood=mood;this.until=this.scene.time.now+1800; }
  animate(time: number, dx: number, dy: number, reduced: boolean, celebrate: boolean) {
    if (dx) this.direction=dx<0?'left':'right'; else if(dy) this.direction=dy<0?'up':'down';
    if (time>this.until) this.mood=null;
    const g=this.art;g.clear();const moving=!!(dx||dy), phase=time/(reduced?180:95), swing=moving?Math.round(Math.sin(phase)*5):0;
    const joy=this.mood==='success'&&celebrate&&!reduced;
    const bob=reduced?0:moving?Math.abs(Math.sin(phase))*1.7:Math.sin(time/800)*.6;
    const lift=joy?-Math.abs(Math.sin(time/130))*5:0;
    const r=(x:number,y:number,w:number,h:number,c:number)=>g.fillStyle(c).fillRect(Math.round(x),Math.round(y+bob+lift),w,h);
    g.fillStyle(0x061420,.38).fillEllipse(0,4,40,12);
    // Articulated hips, shins, knee joints and boots.
    const leg=(x:number,offset:number)=>{r(x,-15,7,12,0x193a68);r(x+1,-6+offset/2,6,9,0x467bc0);r(x,-7+offset/2,8,4,0xb6bdad);r(x-2,3+offset,13,5,0x101e3d);r(x-1,3+offset,10,3,0x6998d0);};
    leg(-12,swing);leg(6,-swing);
    // Arms are independently posed; Byte reaches out on interaction.
    const wave=this.mood==='wave'||this.mood==='success';
    const arm=(x:number,flip:number)=>{const raised=wave&&flip===1;const y=raised?-47:-29+flip*swing/2;r(x,y,7,13,0x254f91);r(x+flip*2,y+9,7,7,0x7c9cb9);r(x+flip*3,y+(raised?-5:14),8,8,0xe3d3a3);r(x+flip*4,y+(raised?-3:16),3,3,0xb79f7e);};
    arm(-25,-1);arm(19,1);
    // Blue enclosure and cream CRT bezel retain the reference's silhouette.
    const side=this.direction==='left'?-3:this.direction==='right'?3:0;
    r(-21,-55,40,36,0x061632);r(-18,-58,34,5,0x285fb0);r(17,-51,7,31,0x1c4080);r(-19,-53,36,34,0x3b72b7);r(-17,-51,32,29,0xf5e4b6);r(-14,-48,26,23,0x162c53);
    r(-21,-22,44,10,0x17366b);r(-17,-21,32,5,0x6592c5);r(-14,-19,11,2,0x1b3868);r(15,-20,3,4,0xffc34b);
    if(this.direction==='up') {
      r(-15,-50,29,26,0x235393);for(let i=0;i<4;i++)r(-10,-44+i*5,19,2,0x0b2550);r(-3,-29,7,5,0x5a84b6);
    } else {
      r(-12,-46,23,2,0x284d7b);r(-10,-44,4,3,0x8aa7ba);
      const blink=time%5800>5580;const eyeY=this.mood==='success'?-36:-34;
      if(this.mood==='error') {r(-9+side,-36,7,2,0xf8b847);r(3+side,-36,7,2,0xf8b847);r(-6+side,-39,2,7,0xf8b847);r(6+side,-39,2,7,0xf8b847);}
      else {r(-10+side,eyeY,8,blink?2:3,0xffc448);r(3+side,eyeY+1,8,blink?2:3,0xffc448);if(!blink){r(-7+side,eyeY+3,4,2,0xd99c27);r(5+side,eyeY+4,4,2,0xd99c27);}}
      r(-2+side,-28,this.mood==='success'?8:5,2,0xffc448);
      // Sticky note from the reference, attached to the upper corner.
      r(10,-55,11,14,0x102342);r(9,-56,11,13,0xf3bd48);r(11,-52,6,1,0x6c591e);r(11,-49,5,1,0x6c591e);r(11,-46,4,1,0x6c591e);
    }
    this.bubble.setText(this.mood?({wave:'Oi! >_',think:'hmm...',success:'+ XP!',error:'vamos revisar'}[this.mood]):'').setVisible(!!this.mood);
  }
}
