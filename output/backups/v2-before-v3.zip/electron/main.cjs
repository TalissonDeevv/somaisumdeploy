const { app, BrowserWindow, session } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
app.whenReady().then(() => {
  const entry = pathToFileURL(path.join(__dirname, '../dist/index.html')).href;
  session.defaultSession.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false));
  const createWindow = () => {
    const win = new BrowserWindow({ width: 1440, height: 900, minWidth: 800, minHeight: 600, backgroundColor: '#101923', autoHideMenuBar: true,
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true } });
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', (event, url) => { if (url !== entry) event.preventDefault(); });
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  };
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => app.quit());
