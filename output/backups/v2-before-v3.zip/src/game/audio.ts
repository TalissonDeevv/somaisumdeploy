import type { Settings } from '../core/types';
export class GameAudio {
  private context?: AudioContext;
  private ambienceGain?: GainNode;
  constructor(private settings: () => Settings) {}
  unlock() { try { this.context ??= new AudioContext(); void this.context.resume(); this.syncAmbience(); } catch { /* Audio is optional. */ } }
  syncAmbience() {
    if(!this.context)return;
    const ctx=this.context,s=this.settings();
    if(!this.ambienceGain){
      this.ambienceGain=ctx.createGain();this.ambienceGain.gain.value=0;this.ambienceGain.connect(ctx.destination);
      [110,164.81].forEach(f=>{const osc=ctx.createOscillator();osc.frequency.value=f;osc.type='sine';osc.connect(this.ambienceGain!);osc.start();});
    }
    this.ambienceGain.gain.setTargetAtTime(s.ambience&&!s.muted?s.ambienceVolume*.035:0,ctx.currentTime,.2);
  }
  quiet() { if(this.ambienceGain&&this.context)this.ambienceGain.gain.setTargetAtTime(0,this.context.currentTime,.15); }
  play(success = false) {
    const s = this.settings(); if (!this.context || s.muted || s.volume === 0) return;
    const ctx = this.context;
    (success ? [440, 554, 659] : [370]).forEach((frequency, index) => {
      const osc = ctx.createOscillator(), gain = ctx.createGain(), now = ctx.currentTime + index * 0.09;
      osc.type = 'sine'; osc.frequency.value = frequency; gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(s.volume * 0.12, now + 0.01); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.18);
    });
  }
}
